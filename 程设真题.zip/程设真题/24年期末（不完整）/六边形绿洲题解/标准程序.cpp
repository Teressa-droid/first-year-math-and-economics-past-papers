#include <algorithm>
#include <cmath>
#include <iostream>
#include <queue>
#include <sstream>
#include <string>
#include <vector>
using namespace std;

// 定义一个格子的结构体
struct Node {
  int _type = 0;          // 格子类型
  int _neighbor[6] = {0}; // 格子邻居
  int _connect[6] = {0};  // 格子连通性
  int _offset = 0;        // 逆时针旋转次数
  int _depth = 0;         // 与目标的距离
  // 根据与目标的距离排序后的邻居id
  vector<pair<int, int>> _sorted_neighbor;
  // 获取edge_id对应的邻居id
  static int get_neighbor_edge_id(int edge_id) { return (edge_id + 3) % 6; }

  static int get_wrap_id(int id) { return (id + 6) % 6; }

  // 获取旋转后的edge_id这条边的连通性
  int get_connect(int edge_id) {
    return _connect[get_wrap_id(edge_id + _offset)];
  }
};

int n = 0;
vector<Node> nodes; // 存储所有的格子
vector<bool> visit; // 存储格子是否被访问过
int dst_id = 0;     // 目标（生命之树）格子的id
int src_id = 0;     // 水源格子的id

// 打印结果
void print_solution() {
  int m = 0;
  // 申明一个string流
  stringstream ss;
  // 遍历所有的node
  for (int i = 1; i < nodes.size(); i++) {
    int offset = nodes[i]._offset % 6;
    // 如果格子有旋转过，才输出旋转方案，没有旋转过就不输出
    if (offset) {
      m++;
      ss << i << " ";
      if (offset > 3) {
        // 如果逆时针旋转次数大于3了，那么顺时针转更方便
        ss << "R ";
        ss << abs(offset - 6);
      } else {
        // 否则直接输出结果
        ss << "L ";
        ss << offset;
      }
      ss << endl;
    }
  }
  // 输出方案中要操作的次数
  cout << m << endl;
  // 输出解决方案
  cout << ss.str();
}

// 递归回溯搜索
void a_star_dfs(int cur_id, int from_edge_id) {
  auto &cur_node = nodes[cur_id];
  auto inner_from_edge_id = Node::get_neighbor_edge_id(from_edge_id);

  // 找到能够到达的邻居，而且是优先找离目标更近的邻居进行搜索
  for (auto it = cur_node._sorted_neighbor.begin();
       it != cur_node._sorted_neighbor.end(); it++) {
    int neighbor_node_id = cur_node._neighbor[it->first];
    auto &neighbor_node = nodes[neighbor_node_id];

    // 邻居节点是否被访问过了
    if (visit[neighbor_node_id])
      continue;

    // 度是否为0，有些格子可能是没有任何水渠的“空格子”
    int conn_cnt = 0;
    for (int ci = 0; ci < 6; ci++) {
      conn_cnt += neighbor_node._connect[ci];
    }
    if (conn_cnt == 0)
      continue;

    // 尝试每一种旋转方法
    for (cur_node._offset = 0; cur_node._offset < 6; cur_node._offset++) {
      // 确定该旋转方法是否会导致没法接上parent node
      if (from_edge_id != -1 && cur_node.get_connect(inner_from_edge_id) == 0)
        continue;
      
      // 如果当前格子是生命之树格子，则打印结果
      if (cur_node._type == 2) {
        print_solution();
        exit(0);
      }

      // 确定该旋转方法是否会导致第i条边界没有水渠通向它
      if (cur_node.get_connect(it->first) == 0)
        continue;

      visit[neighbor_node_id] = true;

      // 递归搜索
      a_star_dfs(neighbor_node_id, it->first);
      visit[neighbor_node_id] = false;
    }
  }
}

bool compare(const std::pair<int, int> &a, const std::pair<int, int> &b) {
  return a.second < b.second;
}

void a_star_solution() {
  // 从生命之树格子开始，使用BFS遍历整个地图，设置每一个格子到目标的距离
  // 使用队列进行BFS
  queue<int> q;
  vector<bool> bfs_visit(n + 1, false);
  // 将目标格子的id加入到队列中
  q.push(dst_id);
  // 并将目标格子标记为已访问
  bfs_visit[dst_id] = true;
  while (!q.empty()) {
    int cur_id = q.front();
    q.pop();
    auto &cur_node = nodes[cur_id];
    // 对于每一个格子，逐个遍历他们的邻居
    for (int i = 0; i < 6; i++) {
      int neighbor_id = cur_node._neighbor[i];
      if (neighbor_id == 0)
        continue;
      if (bfs_visit[neighbor_id] == true)
        continue;
      bfs_visit[neighbor_id] = true;
      // 邻居距离生命之树格子的距离=当前格子的距离+1
      nodes[neighbor_id]._depth = cur_node._depth + 1;
      // 将邻居节点id加入到队列
      q.push(neighbor_id);
    }
  }
  // 根据得到的_depth更新数据结构，对_sorted_neighbor进行排序
  for (auto &node : nodes) {
    for (int i = 0; i < 6; i++) {
      int neighbor_id = node._neighbor[i];
      if (neighbor_id == 0)
        continue;
      node._sorted_neighbor.push_back(make_pair(i, nodes[neighbor_id]._depth));
    }
    // 使用STL提供的排序函数，对_sorted_neighbor进行排序
    // 根据_depth从小到大排（越小说明距离生命之树格子越近）
    sort(node._sorted_neighbor.begin(), node._sorted_neighbor.end(), compare);
  }
  // 根据得到的_depth进行启发式搜索，先遍历靠近目标的
  a_star_dfs(src_id, -1);
}

int main() {
  cin >> n;
  visit = vector<bool>(n + 1, false);
  nodes.push_back(Node());
  for (int i = 1; i <= n; i++) {
    Node _tmp_node;
    cin >> _tmp_node._type;
    for (int j = 0; j < 6; j++)
      cin >> _tmp_node._neighbor[j];
    for (int j = 0; j < 6; j++)
      cin >> _tmp_node._connect[j];
    nodes.push_back(_tmp_node);
    if (_tmp_node._type == 0)
      src_id = i;
    else if (_tmp_node._type == 2)
      dst_id = i;
  }
  a_star_solution();
  return 0;
}