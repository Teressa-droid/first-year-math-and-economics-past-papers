#include <iostream>
#include <vector>
#include <algorithm>
#include <chrono>

using namespace std;

// 判断第col列是否满足要求
bool isValid_col(vector<vector<int>>& grid, vector<int>& colHints, int col, int n){
    // 统计列中连续个1的个数，如果等于colHints[col]，则返回false
    int count = 0;
    for (int i = 0; i < n; ++i) {
        if (grid[i][col] == 1) {
            count++;
            if (count == colHints[col]) {
                return false;
            }
        } else {
            count = 0;
        }
    }
    return true;
}

// 判断所有列是否满足要求
bool isValid(vector<vector<int>>& grid,  vector<int>& colHints, int n) {
    // 因为我们在回溯时保证了行填充的正确性，因此我们只需要判断列是否满足要求即可
    // 我们需要判断任意第j列是否满足有且仅有一段colHints[j]个1连续出现，且其它格子均为0。
    for (int j = 0; j < n; ++j) {
        int count = 0;
        int end = -1;
        for (int i = 0; i < n; ++i) {
            if (grid[i][j] == 1) {
                count++;
                if (count == colHints[j]) {
                    end = i;
                    break;
                }
            } else  {
                count = 0;
            }
        }

        // end == -1说明没有找到连续n个1
        if (end == -1) {
            return false;
        }

        // 找到了连续n个1，检查其它是否都为0
        for(int k = 0; k < end - colHints[j] + 1; k++) {
            if (grid[k][j] != 0) {
                return false;
            }
        }

        for(int k = end + 1; k < n; k++) {
            if (grid[k][j] != 0) {
                return false;
            }
        }
    }
    return true;
}

bool backtrack(vector<vector<int>>& grid, vector<int>& rowHints, vector<int>& colHints, int row, int n) {
    if (row == n) {
        return isValid(grid, colHints, n);
    }

    //枚举每一行连续填充rowHints[row]个1的情况
    for(int i = 0; i <= n - rowHints[row]; ++i) {
        // 边回溯边检查，例如，如果现在第i列已经有2个连续的1了，而colHints[i]要求2个，则不再枚举第i列
        if (!isValid_col(grid, colHints, i, n)) continue;
        fill_n(grid[row].begin() + i, rowHints[row], 1);
        if (backtrack(grid, rowHints, colHints, row + 1, n)) {
            return true;
        }
        fill_n(grid[row].begin() + i, rowHints[row], 0);
    }
    return false;
}

int main() {
    int n;
    cin >> n;

    vector<int> rowHints(n);
    vector<int> colHints(n);
    for (int i = 0; i < n; ++i) {
        cin >> rowHints[i];
    }
    for (int i = 0; i < n; ++i) {
        cin >> colHints[i];
    }

    vector<vector<int>> grid(n, vector<int>(n, 0));

    if (backtrack(grid, rowHints, colHints, 0, n)) {
        for (auto& row : grid) {
            for (int cell : row) {
                cout << cell << " ";
            }
            cout << endl;
        }
    } else {
        cout << "No solution found." << endl;
    }

    return 0;
}