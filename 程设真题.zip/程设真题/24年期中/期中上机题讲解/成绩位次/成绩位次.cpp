#include <stdio.h>
#include <algorithm>
using namespace std;
int yuwen[105], shuxue[105], yingyu[105], zixuan[105], zongfen[105], xuehao[105], r[100005];
void jiaohuan(int i, int j)
{

    //swap(a,b)就是交换a和b的值
    swap(yuwen[i], yuwen[j]);
    swap(shuxue[i], shuxue[j]);
    swap(yingyu[i], yingyu[j]);
    swap(zixuan[i], zixuan[j]);
    swap(zongfen[i], zongfen[j]);
    swap(xuehao[i], xuehao[j]);
}
int main()
{
    int n;
    scanf("%d", &n);
    for (int i = 1; i <= n; i++)
    {
        scanf("%d%d%d%d%d", &xuehao[i], &yuwen[i], &shuxue[i], &yingyu[i], &zixuan[i]);
        zongfen[i] = yuwen[i] + shuxue[i] + yingyu[i] + zixuan[i];
    }
    //先按规则排序
    int rank, key;
    scanf("%d%d", &rank, &key);
    for (int i = 1; i <= n; i++)
        for (int j = i + 1; j <= n; j++)
        {
            if (zongfen[i] < zongfen[j])
                jiaohuan(i, j);
            else if (zongfen[i] == zongfen[j] && yuwen[i] < yuwen[j])
                jiaohuan(i, j);
            else if (zongfen[i] == zongfen[j] && yuwen[i] == yuwen[j] && shuxue[i] < shuxue[j])
                jiaohuan(i, j);
            else if (zongfen[i] == zongfen[j] && yuwen[i] == yuwen[j] && shuxue[i] == shuxue[j] && yingyu[i] < yingyu[j])
                jiaohuan(i, j);
        }
    //排完序了
    r[xuehao[1]] = rank;//记录排在第一个的位次
    for (int i = 2; i <= n; i++)
    {
        if (zongfen[i] == zongfen[i - 1] && yuwen[i] == yuwen[i - 1] && shuxue[i] == shuxue[i - 1] && yingyu[i] == yingyu[i - 1])
            r[xuehao[i]] = r[xuehao[i - 1]];//同分的位次
        else
            r[xuehao[i]] = r[xuehao[i - 1]] + 1;//不同分的位次
    }
    printf("%d", r[key]);
    return 0;
}