#include <bits/stdc++.h>

int a[105][105];//存储原矩阵
int b[105][105];//存储旋转后的矩阵
int n,m;//原矩阵n行m列

int main(){
    std::cin>>n>>m;
    for(int i=0;i<n;i++){
        for(int j=0;j<m;j++){
            std::cin>>a[i][j];//读入原矩阵
        }
    }
    int p;
    std::cin>>p;//读入旋转角度
    while(p<0){
        p+=360;
    }
    while(p>=360){
        p-=360;
    }//将任意角变到[0,360)这个区间内
    p /= 90;//现在p的取值为0，1，2，3
    if(p==0){//p==0表示不用旋转，直接输出
        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                std::cout<<a[i][j]<<" ";
            }
            std::cout<<"\n";
        }
    }
    if(p==2){//旋转180°
        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                b[i][j]=a[n-i-1][m-j-1];
                std::cout<<b[i][j]<<" ";
            }
            std::cout<<"\n";
        }
    }
    if(p==3){//逆时针90°
        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                b[m-j-1][i]=a[i][j];
            }
        }
        for(int i=0;i<m;i++){
            for(int j=0;j<n;j++){
                std::cout<<b[i][j]<<" ";
            }
            std::cout<<"\n";
        }
    }
    if(p==1){//顺时针90°
        for(int i=0;i<n;i++){
            for(int j=0;j<m;j++){
                b[j][n-i-1]=a[i][j];
            }
        }
        for(int i=0;i<m;i++){
            for(int j=0;j<n;j++){
                std::cout<<b[i][j]<<" ";
            }
            std::cout<<"\n";
        }
    }
    return 0;
}