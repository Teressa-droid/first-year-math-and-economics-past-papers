#include <iostream>
#include <stdio.h>
#include <math.h>
#include <string.h>
using namespace std;

int main()
{
    int mtr,n;
    cin>>mtr>>n;
    int a[n]={0},ans=0;
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
    }
    for(int i=0;i<n-1;i++)
    {
        if(a[i+1]-a[i]<mtr)//比较mtr与下一个暂停与本次暂停的时间间隔
        {
            ans+=a[i+1]-a[i];//小于mtr则只需加时间间隔
        }
        else
            ans+=mtr;//大于等于mtr则不会重叠，直接加mtr
    }
    ans+=mtr;//最后一次不需要比较，直接加mtr
    cout<<ans;
}