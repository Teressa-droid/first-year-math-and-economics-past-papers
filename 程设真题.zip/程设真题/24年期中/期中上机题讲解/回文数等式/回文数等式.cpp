#include<bits/stdc++.h>
using namespace std;
int check(int x)
{
    int z=x,y=0;//z用来保留x的值
    while(x)
    {//逐位回文计算
        y*=10;
        y+=x%10;
        x/=10;
    }
    return z==y;
}
int main()
{
    int k;
    cin>>k;
    for(int i=1;i<=k;i++)
    {//穷举，如果是回文数就输出
        if(check(i*i))   cout<<i<<"*"<<i<<"="<<i*i<<endl;
    }
    return 0;
}