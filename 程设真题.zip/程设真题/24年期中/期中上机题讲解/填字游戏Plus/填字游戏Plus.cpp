#include<bits/stdc++.h>
using namespace std;
char maze[2005][2005];
string s;
struct noded{
    int x,xx,y,yy,cnt;
}node;
int m,n;
int dx[5]={0,-1,0,1,0},dy[5]={0,0,-1,0,1};
bool check(int x,int y){
    bool res=0;
    if(maze[x][y]==s[0]||maze[x][y]=='0'||maze[x][y]=='*'){
        for(int d=4;d;--d){
            int xx=x,yy=y,cnt=0;
            if(maze[x][y]=='0')
                cnt++;
            for(int i=1;i<s.size();++i){
                xx+=dx[d],yy+=dy[d];
                if(maze[xx][yy]!=s[i] && maze[xx][yy]!='*' && maze[xx][yy]!='0')
                    break;
                if(maze[xx][yy]=='0')
                    cnt++;
                if(i==s.size()-1 && (maze[xx+dx[d]][yy+dy[d]]=='1' || xx+dx[d]>m || xx+dx[d]<1 || yy+dy[d]<1 || yy+dy[d]>n) && (maze[x-dx[d]][y-dy[d]]=='1' || x-dx[d]>m || x-dx[d]<1 || y-dy[d]<1 || y-dy[d]>n)){
                    res=1;
                    if(node.cnt>cnt)
                        node.x=x,node.y=y,node.xx=xx,node.yy=yy,node.cnt=cnt;
                }
            }
        }
    }
    return res;
}
int main(){
    bool flag=0;
    cin>>m>>n;
    for(int i=1;i<=m;++i)
        for(int j=1;j<=n;++j)
            cin>>maze[i][j];
    cin>>s;
    node.cnt=INT_MAX;
    for(int i=1;i<=m;++i)
        for(int j=1;j<=n;++j)
            if(check(i,j))
                flag=1;
    if(!flag)
        cout<<"No";
    else
        cout<<node.x-1<<" "<<node.y-1<<endl<<node.xx-1<<" "<<node.yy-1;
    return 0;
}