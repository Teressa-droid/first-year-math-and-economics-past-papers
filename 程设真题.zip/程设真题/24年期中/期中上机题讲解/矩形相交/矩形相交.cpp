#include<bits/stdc++.h>
using namespace std;
struct pii {int x,y;}; // 点的二维坐标系下坐标
struct node {int a,b,c,d;}; // 用处于同一对角线的两个顶点坐标（a,b) (c,d) 描述一个矩形
inline int count(node x,node y) {
    pii a[4]; // 矩形 x 的四个顶点的坐标
    a[0]={x.a,x.b};
    a[1]={x.a,x.d};
    a[2]={x.c,x.b};
    a[3]={x.c,x.d};
    int c=0;
    for(int i=0;i<4;i++)
        if(y.a<=a[i].x&&a[i].x<=y.c&&y.b<=a[i].y&&a[i].y<=y.d) 
            c++;
    return c;
} // 统计矩形 x 有多少个顶点在 矩形y 的内部或边界
int x[2],y[2],xx[2],yy[2];
int main() {
    for(int t=0;t<2;t++) scanf("%d%d%d%d",&x[t],&y[t],&xx[t],&yy[t]); // 读入两个矩形（0号和1号）


    // 确定矩形顶点位置和矩形相对位置，方便分类讨论

    // 使 (x[i],y[i]) 为左下角， (xx[i],yy[i]) 为右上角
    if(x[0]>xx[0]) swap(x[0],xx[0]);
    if(y[0]>yy[0]) swap(y[0],yy[0]);
    if(x[1]>xx[1]) swap(x[1],xx[1]);
    if(y[1]>yy[1]) swap(y[1],yy[1]);

    // 使 0 号矩形在 1 号左边
    if(x[0]>x[1]) {
        swap(x[0],x[1]);
        swap(y[0],y[1]);
        swap(xx[0],xx[1]);
        swap(yy[0],yy[1]);
    }

    // 先判断可以直接判断的
    if(x[0]==x[1]&&y[0]==y[1]&&xx[0]==xx[1]&&yy[0]==yy[1]) puts("12"); // 重合
    else if(x[1]>xx[0]||y[1]>yy[0]||yy[1]<y[0]) puts("0"); // 不相交
    else if((xx[0]==x[1]&&yy[0]==y[1])||(x[0]==xx[1]&&yy[0]==y[1])) puts("1"); // 只有一个顶点相交
    else if(y[0]==yy[1]||yy[0]==y[1]||x[0]==xx[1]||xx[0]==x[1]) puts("2"); // 边重合点不重和

    // 按照 一个矩形在另一个矩形内部的顶点个数 确定矩形之间的关系
    else {
        node a={x[0],y[0],xx[0],yy[0]},b={x[1],y[1],xx[1],yy[1]};
        if(count(a,b)+count(b,a)==0) puts("10"); // 十字交叉，没有顶点在对方内部
        else if(count(a,b)==1&&count(b,a)==1) puts("4"); // 互相有一个顶点在对方内部
        else if(count(a,b)==4||count(b,a)==4) puts("8"); // 一个矩形完全在另一个内部
        else puts("6"); // 最麻烦判断的放在 else
    }
    return 0;
}