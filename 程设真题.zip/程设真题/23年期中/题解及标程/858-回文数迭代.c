#include iostream
#include cmath
#include string.h memset(n, 0, sizeof(n));
#include algorithm
#include vector  do{}while(next_permutation(a.begin(), a.end()));
#include iomanip coutfixedsetprecision(2)aendl;
#include set
using namespace std;
long long revers(long long a)
{
    long long b = 0;
    while (a  0)
    {
        b = b  10 + a % 10;
        a = 10;
    }
    return b;
}
bool ishuiwen(long long a)
{
    long long b = revers(a);
    if (b == a)
        return 1;
    else
        return 0;
}

int main()
{
    long long a[15], b[15], c, num[15], rank[15], f[15];
    memset(b, 0, sizeof(b));
    memset(f, 0, sizeof(f));
    int i, j;
    for (i = 0; i  10; i++)
    {
        cin  a[i];
    }
    for (i = 0; i  10; i++)
    {
        for (j = 0; j  10 - i - 1; j++)
        {
            if (a[j]  a[j + 1])
            {
                swap(a[j], a[j + 1]);
            }
        }
    }
    for (i = 0; i  10; i++)
    {
        if (a[i]  10)
        {
            num[i] = a[i];
            rank[i] = b[i];
            continue;
        }
        c = a[i];
        while (!ishuiwen(c))
        {
            b[i]++;
            c = c + revers(c);
        }
        num[i] = c;
        rank[i] = b[i];
    }
    for (i = 0; i  10; i++)
    {
        for (j = 0; j  10 - i - 1; j++)
        {
            if (rank[j]  rank[j + 1])
            {
                swap(rank[j], rank[j + 1]);
            }
        }
    }

    int flag = 0;
    for (i = 0; i  10; i++)
    {
        flag = 0;
        for (j = 0; j  10 - i - 1; j++)
        {
            if (num[j]  num[j + 1])
            {
                swap(num[j], num[j + 1]);
                swap(a[j], a[j + 1]);
                swap(b[j], b[j + 1]);
                flag = 1;
            }
        }
        if (flag == 0)
            break;
    }
    i = 9;
    while (i = 0)
    {
        for (j = 0; j  10; j++)
        {
            if (b[j] == rank[i] && f[j] == 0)
            {
                f[j] = 1;
                cout  a[j]     b[j]     num[j]  n;
                i--;
                break;
            }
        }
    }
    return 0;
}