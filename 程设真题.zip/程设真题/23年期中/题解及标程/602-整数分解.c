#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
bool vis[2005];
int prime[1005];
int tot,n,k;
int main()
{
  for(int i=2;i<=1000;i++)
    if(!vis[i])
    {
     prime[++tot]=i;
     for(int j=2;j*i<=1000;j++)
      vis[j*i]=1;
    }
 scanf("%d",&n);
 for(int i=1;i<=n;i++)
 {
    int sum=0;
   scanf("%d",&k);
   for(int j=1;j<=tot;j++)
     for(int h=j+1;h<=tot;h++)
     {
       if(k-prime[j]-prime[h]<=prime[h]) break;
	   if(k-prime[j]-prime[h]>1000) continue;
       if(!vis[k-prime[j]-prime[h]] && k-prime[j]-prime[h]!=prime[j] && prime[h]!=k-prime[j]-prime[h] )
         sum++;
     }
  cout<<sum<<" ";
 }

 return 0;
}
