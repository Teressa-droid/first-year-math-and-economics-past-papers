#include<bits/stdc++.h>
using namespace std;
int year,n,m;
int hmd[13]={0,31,28,31,30,31,30,31,31,30,31,30,31};//存储每月的天数
int whichweek[13][32];//存储某月某日是当年的第几周
struct week
{
    int kid,boy;//本周新生儿数和新生男孩数
    char se[2][6];//se[0]存储本周起始日期，se[1]存储本周终止日期
}w[60];
void store_se(int weeknum,int month,int day,int t)//供calweek函数调用，存储某一周的起始和终止日期；t=0代表存入起始，t=1代表存入终止
{
    w[weeknum].se[t][5]='\0';//便于输出字符串
    w[weeknum].se[t][4]=char(day%10+48);//日的个位
    day/=10;
    w[weeknum].se[t][3]=day?char(day+48):' ';//日的十位，若为0则存空格
    w[weeknum].se[t][2]='.';
    w[weeknum].se[t][1]=char(month%10+48);//月的个位
    month/=10;
    w[weeknum].se[t][0]=month?char(month+48):' ';//月的十位，若为0则存空格
}
void calweek()//核心函数：预处理whichweek和se数组
{
    int y=1969,startday=3;//先从1969开始穷举年份，计算当年的1月1日是星期几，用变量startday记录
    //startday=0~6分别代表周日、周一、…… 、周六
    while(y<year)//计算当年的startday，穷举至前一年为止
    {
        startday+=365+(y%4==0);//闰年加一天（考虑到年份范围是1969-2019，所以只需%4判断闰年）
        startday%=7;
        y++;
    }
    //以下通过一轮穷举同时处理whichweek和se数组，实现日期和周数双向检索
    int weekday=startday-1,weeknum=1-(startday==0);//此处为了保证后续循环正常更新weeknum，如果1月1日是周日则weeknum从0开始，否则从1开始
    //weekday代表星期几，weeknum代表第几周
    for(int month=1;month<=12;month++)
    {
        for(int day=1;day<=hmd[month];day++)
        {//二重循环穷举日期
            weekday=(weekday+1)%7;//同步更新星期
            weeknum+=(weekday==0);//每到周日更新周数
            whichweek[month][day]=weeknum;//记录某月某日是星期几
            if(weekday==0||(month==1&&day==1))//每到周日或1月1日更新当周起始日期
                store_se(weeknum,month,day,0);
            if(weekday==6||(month==12&&day==31))//每到周六或12月31日更新当周终止日期
                store_se(weeknum,month,day,1);
        }
    }
}
void sort()//冒泡排序
{
    for(int i=1;i<=54;i++)//一年最多涵盖54周
    {
        for(int j=1;j<55-i;j++)
        {
            if(w[j].kid<w[j+1].kid) swap(w[j],w[j+1]);
        }
    }
}
int main()
{
    cin>>year>>n>>m;
    hmd[2]+=(year%4==0);//若为闰年则给2月加一天（考虑到年份范围是1969-2019，所以只需%4判断闰年）
    calweek();
    int id,month,day,sex;
    for(int i=1;i<=n;i++)
    {//用预处理的whichweek数组做输入统计
        cin>>id>>month>>day>>sex;
        w[whichweek[month][day]].kid++;
        w[whichweek[month][day]].boy+=sex;//男孩时sex=1，女孩时sex=0
    }
    sort();//排序
    for(int i=1;i<=m;i++)
    {//用预处理的se数组做格式化输出
        cout<<"["<<w[i].se[0]<<"-"<<w[i].se[1]<<"]:"<<w[i].kid<<"(B"<<w[i].boy<<")\n";
    }
}