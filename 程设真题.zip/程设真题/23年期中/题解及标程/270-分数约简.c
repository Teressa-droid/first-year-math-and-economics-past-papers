#define _CRT_SECURE_NO_WARNINGS 1
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int is_end(int n, int m)
{
	for (int i = 2; i <= fmin(n, m); i++)
	{
		if (n % i == 0 && m % i == 0)
		{
			return 1;
		}
	}
	return 0;
}


int main()
{
	int n = 0, m = 0;
	scanf("%d/%d", &n, &m);
	while (is_end(n, m))
	{
		for (int i = 2; i <= fmin(n, m); i++)
		{
			if (n % i == 0 && m % i == 0)
			{
				n /= i;
				m /= i;
			}
		}
	}
	printf("%d/%d", n, m);

	return 0;
}