#include <bits/stdc++.h>
using namespace std;
const int maxn=2005;
int d[maxn][maxn]; // the min right move pace to reach a point
bool vis[maxn][maxn];
int n,m;
int r,c;  //from
int x,y; //x: l limit y r limit
char s[maxn][maxn];
int dx[4]={0,0,1,-1};
int dy[4]={1,-1,0,0};
int ans;
bool noob(int ux,int uy)
{
    if(s[ux][uy]=='*')return 0;
    else return 1;
}
bool inspace(int ux,int uy)
{
    if(ux<1||ux>n)return 0;
    if(uy<1||uy>m)return 0;
    return 1;
}
bool pass(int ux,int uy)
{
    if(noob(ux,uy)&&inspace(ux,uy))return 1;
    else return 0;
}
void bfs()
{
    queue< pair<int,int> >q;
    d[r][c]=0;
    q.push(make_pair(r,c));
    vis[r][c]=1;ans++;
    while(!q.empty())
    {
        int ux=q.front().first;
        int uy=q.front().second;
        q.pop();
       // cout<<ux<<uy<<" "<<d[ux][uy]<<endl;
        for(int i=0;i<4;i++)
        {
            int vx=ux+dx[i];
            int vy=uy+dy[i];
            if(!pass(vx,vy))continue;
            int dv=d[ux][uy];
            if(i==0)dv++;
            if(dv>y)continue;
            //mover-movel=vy-c;
            if(dv-vy+c>x)continue;
            if(!vis[vx][vy])
            {
                vis[vx][vy]=1;
                d[vx][vy]=dv;
                ans++;
                q.push(make_pair(vx,vy));
            }
            else
            {
                if(dv<d[vx][vy])
                {
                    d[vx][vy]=dv;
                    q.push(make_pair(vx,vy));
                }
            }
        }
    }
}
void solve()
{
    scanf("%d%d",&n,&m);
    scanf("%d%d",&r,&c);
    scanf("%d%d",&x,&y);
    for(int i=1;i<=n;i++)
    {
        scanf("%s",s[i]+1);
    }
    bfs();
    cout<<ans;

}
int main()
{
    int tt;tt=1;
    while(tt--)solve();
    return 0;
}