#include <stdio.h>
#include <string.h>

int n, m;
int access_first[2010];
int access_second[2010];
int occupied[2010];
int max_hits = 0;
int min_hits = 0x7fffffff;

void max_cache_hits(int k, int hits, int miss) {
    if(k == n) {
        if (hits > max_hits)
            max_hits = hits;
        if (miss < min_hits)
            min_hits = miss;
        return;
    }
    if(miss >= min_hits)
        return;
    // no cache k's entry
    max_cache_hits(k + 1, hits, miss + 1);
    // cache k's entry
    int start = access_first[k];
    int end = access_second[k];
    for (int i = start; i < end; ++i) {
        if(occupied[i] >= m)
            return;
    }
    for (int i = start; i < end; ++i)
        occupied[i]++;
    max_cache_hits(k + 1, hits + 1, miss);
    for (int i = start; i < end; ++i) // 回溯
        occupied[i]--;
}

int main() {
    scanf("%d %d", &n, &m);

    memset(access_first, -1, sizeof(access_first));
    memset(access_second, -1, sizeof(access_second));

    for (int i = 0; i < 2 * n; i++) {
        int entry;
        scanf("%d", &entry);
        if(access_first[entry] == -1)
            access_first[entry] = i;
        else
            access_second[entry] = i;
    }

    max_cache_hits(0, 0, 0);
    printf("%d\n", max_hits);

    return 0;
}
