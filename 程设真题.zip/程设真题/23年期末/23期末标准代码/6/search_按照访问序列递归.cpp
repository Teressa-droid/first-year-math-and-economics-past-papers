#include <stdio.h>

int n, m;
int access_sequence[2010] = {0};
int is_cache[1010] = {0};

int max_hits = 0;

void max_cache_hits(int k, int cache_num, int hits) {
    if(k == 2 * n) {
        if(hits > max_hits)
            max_hits = hits;
        return;
    }
    if(is_cache[access_sequence[k]] == 1) {
        max_cache_hits(k + 1, cache_num, hits + 1);
    }
    else if (cache_num < m) {
        is_cache[access_sequence[k]] = 1;
        max_cache_hits(k + 1, cache_num + 1, hits);
    }
    else {
        // 不cache
        max_cache_hits(k + 1, cache_num, hits);
        // 选择cache中一个淘汰，再cache当前
        for (int i = 0; i < n; ++i) {
            if(is_cache[i] == 0)
                continue;
            is_cache[i] = 0;
            is_cache[access_sequence[k]] = 1;
            max_cache_hits(k + 1, cache_num, hits);
            is_cache[access_sequence[k]] = 0;
            is_cache[i] = 1;
        }
    }
}

int main() {
    scanf("%d %d", &n, &m);
    for (int i = 0; i < 2 * n; i++)
        scanf("%d", &access_sequence[i]);

    max_cache_hits(0, 0, 0);
    printf("%d\n", max_hits);

    return 0;
}
