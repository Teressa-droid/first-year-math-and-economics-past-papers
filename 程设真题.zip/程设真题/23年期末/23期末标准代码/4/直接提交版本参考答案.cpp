#include <iostream>
#include <vector>
#include <stack>
using namespace std;

int main()
{
    int n, m, max = 0;
    cin >> n >> m;
    vector<int> heights(m + 2, 0);
    int dot;
    for (int i = 0; i < n; ++i) {
        for (int j = 1; j <= m; ++j) {
            cin >> dot;
            if(dot == 0)
                heights[j]++;
            else 
                heights[j] = 0;
        }
        stack<int> s;
        for (int j = 0; j <= m + 1; ++j) {
            while(!s.empty() && heights[s.top()] > heights[j]) {
                int t = s.top();
                s.pop();
                int area = heights[t] * (j - s.top() - 1);
                if(area > max)
                    max = area;
            }
            s.push(j);
        }
    }
    cout << max << endl;
    return 0;
}