#include <stdio.h>
int n, m, a, b, c;
int num[10];
int used[10];
int w[4];
int sum = 0;
int trans(int ary[10], int low, int high)
{
    int weight = 1, ans = 0;
    for (int i = low + 1; i <= high; i++)
    {
        ans += ary[i] * weight;
        weight *= 10;
    }
    return ans;
}
void dfs(int k, int shengyu, int ary[10])
{
    if (k > 2)
    {
        a = trans(ary, w[0], w[1]);
        b = trans(ary, w[1], w[2]);
        c = trans(ary, w[2], w[3]);
        if (b % c != 0 || b == 0)
        {
            return;
        }
        if (n == a + b / c)
        {
            // printf("%d+%d/%d\n", a, b, c);
            sum++;
        }
        return;
    }
    for (int i = 1; i <= m - 1 - shengyu; i++)
    {
        w[k] = i;
        dfs(k + 1, shengyu - 1, ary);
        w[k] = 0;
    }
}
void quanpailie(int k)
{
    if (k > m)
    {
        dfs(1, 1, num);
        return;
    }
    for (int i = 1; i <= m; i++)
    {
        if (used[i] == 0)
        {
            num[k] = i;
            used[i] = 1;
            quanpailie(k + 1);
            num[k] = 0;
            used[i] = 0;
        }
    }
}
int main()
{
    scanf("%d %d", &n, &m);
    w[0] = 0;
    w[3] = m;
    quanpailie(1);
    printf("%d", sum);
}